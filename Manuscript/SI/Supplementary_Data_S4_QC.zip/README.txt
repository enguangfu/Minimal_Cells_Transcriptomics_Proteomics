Supplementary Data S4 -- RNA-sample quality control
===================================================

Raw RNA-sample quality-control reports for the sequencing libraries used
in this study, as provided by the sequencing facilities. They report RNA
concentration and fragment-size integrity (Qubit / Agilent TapeStation /
Bioanalyzer) and, where applicable, ribosomal-RNA depletion (loss of the
16S and 23S peaks). Each report is a separate file (PDF or PNG) in this archive:

Organism  Platform                    File
------------------------------------------
Syn1      PacBio (cDNA / library QC)  S4_Syn1_PacBio_cDNA_library_QC.pdf
Syn1      Illumina RNA QC (2023-08)   S4_Syn1_Illumina_RNA_QC_2023-08.pdf
Syn1      Illumina RNA QC (2023-09)   S4_Syn1_Illumina_RNA_QC_2023-09.pdf
Syn1      ONT direct-RNA QC (run 1)   S4_Syn1_ONT_directRNA_QC.png
Syn3A     ONT direct-RNA QC           S4_Syn3A_ONT_directRNA_QC.pdf

Note: Syn3A Illumina reads came from a public dataset (Sandberg et al.)
and therefore have no in-house RNA-sample QC report.

Report legends
--------------

S4_Syn1_ONT_directRNA_QC.png:
ONT RNA quality control (Syn1.0, ONT run 1). RNA traces for quality assessment of the
initial JCVI-syn1.0 sample on an Agilent Bioanalyzer 2100, for Oxford Nanopore direct-RNA
sequencing. (top) Total RNA before ribosomal-RNA (rRNA) depletion with an Invitrogen
RiboMinus Bacteria 2.0 Transcriptome Isolation Kit. (mid) After one round of rRNA
depletion the sample contained 9.8% rRNA. (bot) After a second cycle rRNA was reduced to
0.8%. Our threshold for maximum rRNA content was <= 3%.

S4_Syn3A_ONT_directRNA_QC.pdf:
ONT RNA quality control (Syn3A). RNA traces for quality assessment of JCVI-syn3A samples
on an Agilent TapeStation 2200, for Oxford Nanopore direct-RNA sequencing. (top) Total RNA
before ribosomal-RNA (rRNA) depletion with a NEBNext rRNA Depletion Kit for Bacteria.
(bot) After rRNA depletion. Our threshold for maximum rRNA content was <= 3%.
