Supplementary Data S4 -- RNA-sample quality control
===================================================

Raw RNA-sample quality-control reports for the sequencing libraries used
in this study, as provided by the sequencing facilities. They report RNA
concentration and fragment-size integrity (Qubit / Agilent TapeStation /
Bioanalyzer) and, where applicable, ribosomal-RNA depletion (loss of the
16S and 23S peaks). Each report is a separate PDF in this archive:

Organism  Platform                    File
------------------------------------------
Syn1      PacBio (cDNA / library QC)  S4_Syn1_PacBio_cDNA_library_QC.pdf
Syn1      Illumina RNA QC (2023-08)   S4_Syn1_Illumina_RNA_QC_2023-08.pdf
Syn1      Illumina RNA QC (2023-09)   S4_Syn1_Illumina_RNA_QC_2023-09.pdf
Syn3A     ONT direct-RNA QC           S4_Syn3A_ONT_directRNA_QC.pdf

Note: Syn3A Illumina reads came from a public dataset (Sandberg et al.)
and therefore have no in-house RNA-sample QC report.
